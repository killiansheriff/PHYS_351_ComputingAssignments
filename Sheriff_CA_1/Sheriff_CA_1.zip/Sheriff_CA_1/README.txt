On MacOS:

For Task 1: 

- Open a terminal and type "cd PATH_FILE_DIRECTORY" and click enter.
(example: cd /Users/Killian/Documents/OneDrive/Homeworks/WINTER_2020/PHYS_351/Sheriff_CA_1)

- In the terminal type "gcc main_task_1.c vector_mtx.c -o task1" to compile and create an executable named task1. Click enter.

- In the terminal type "./task1" and hit enter to execute the program.



For Task2: 

- Open a terminal and type "cd PATH_FILE_DIRECTORY" and click enter.
(example: cd /Users/Killian/Documents/OneDrive/Homeworks/WINTER_2020/PHYS_351/Sheriff_CA_1)

- In the terminal type "gcc main.c params.c -o init_test" to compile and create an executable named init_test. Click enter.

- In the terminal type "./init_test ./my_input.txt" and hit enter to execute the program.

(Note: my_input.txt is formatted as comma separated (ie: if we want to read the value of position x and momentum p then our first row should be "x, p" 