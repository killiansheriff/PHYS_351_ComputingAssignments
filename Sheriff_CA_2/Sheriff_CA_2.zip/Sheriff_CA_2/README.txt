
Forward Euler, Backward Euler, Leapfrog1 and Leapfrog 2 code implementation (respectively choice 1,2,3,4)

On MacOS:

For Task 1: 

- Open a terminal and type "cd PATH_FILE_DIRECTORY" and click enter.


- In the terminal type "gcc main.c init.c forces.c analysis.c vector_mtx.c evolve.c -o exec" to compile and create an executable named exec. Click enter.

- In the terminal type "./exec ./inputs.txt" and hit enter to execute the program.

Note: For clarity, the inputs.txt has to be formatted as the following:

mass = 2.000000e+00
x_i = 1.000000e+00
p_i = 5.000000e-01
t_i = 0.000000e+00
t_f = 5.000000e+02
it_max = 1500
choice = 4
num_eq = 1
spring const k = 1.000000e-01
h = 3.333333e-01



